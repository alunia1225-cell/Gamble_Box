const KEY="gb3_save";
const S=JSON.parse(localStorage.getItem(KEY)||'{"coins":10000,"wagered":0,"profit":0,"wins":0,"maxwin":0,"history":[],"lastDaily":0,"items":[],"sound":true}');
const $=id=>document.getElementById(id); let audioCtx=null,lastBet=0,timer=null,multi=1;

function save(){localStorage.setItem(KEY,JSON.stringify(S));render()}
function fmt(n){return Math.floor(n).toLocaleString()}
function audio(){if(!S.sound)return null; try{return audioCtx||(audioCtx=new (window.AudioContext||window.webkitAudioContext)())}catch(e){return null}}
function tone(freq,d=.08,type="sine",vol=.035,delay=0){let a=audio();if(!a)return;let o=a.createOscillator(),g=a.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(0.0001,a.currentTime+delay);g.gain.exponentialRampToValueAtTime(vol,a.currentTime+delay+.01);g.gain.exponentialRampToValueAtTime(.0001,a.currentTime+delay+d);o.connect(g);g.connect(a.destination);o.start(a.currentTime+delay);o.stop(a.currentTime+delay+d+.02)}
\nfunction audioFile(name){\n  if(!S.sound) return;\n  try{ const a=new Audio(name); a.volume=0.7; a.preload="auto"; a.play().catch(()=>{}); }catch(e){}\n}\n\nfunction sfx(name){if(!S.sound)return; const fileMap={click:"click.wav",chip:"chip.wav",card:"card.wav",win:"win.wav",lose:"lose.wav",spin:"spin.wav",dice:"dice.wav",roulette:"roulette.wav",crash:"crash.wav",jackpot:"jackpot.wav",flip:"flip.wav",deal:"card.wav"}; if(fileMap[name]) audioFile(fileMap[name]);
 const sets={click:[[180,.05]],chip:[[450,.05,"square"]],card:[[850,.045,"triangle"]],win:[[523,.08],[659,.08],[784,.16]],lose:[[180,.15],[120,.18]],spin:[[180,.05],[220,.05],[280,.05]],dice:[[220,.05],[330,.05],[180,.07]],roulette:[[260,.04],[320,.04],[390,.04],[460,.05]],crash:[[180,.15,"sawtooth"],[80,.35,"sawtooth"]],jackpot:[[392,.1],[523,.1],[659,.1],[1046,.3]],flip:[[600,.08],[400,.08]],deal:[[700,.05],[900,.05]]};
 (sets[name]||sets.click).forEach((x,i)=>tone(x[0],x[1],x[2]||"sine",.035,i*.06));
}
function wager(v){v=Number(v);if(!Number.isFinite(v)||v<1||v>S.coins)return 0;S.coins-=v;S.wagered+=v;lastBet=v;sfx("chip");return v}
function settle(b,p,g){let net=p-b;S.coins+=p;S.profit+=net;if(p>b){S.wins++;S.maxwin=Math.max(S.maxwin,net)}S.history.unshift({g,net,t:new Date().toLocaleTimeString()});S.history=S.history.slice(0,20);save();return net}
function render(){$("coins").textContent=fmt(S.coins);$("coins2").textContent=fmt(S.coins);$("profit").textContent=(S.profit>=0?"+":"")+fmt(S.profit);$("wagered").textContent=fmt(S.wagered);$("level").textContent=Math.floor(S.wagered/10000)+1;$("history").innerHTML=S.history.length?S.history.map(x=>`<div class="history-row"><span>${x.g}</span><b class="${x.net>=0?"win":"lose"}">${x.net>=0?"+":""}${fmt(x.net)}</b><small>${x.t}</small></div>`).join(""):"<div class='history-row'>NO DATA</div>";let names=["YOU","777_MASTER","BLACK_KING","LUCKY_ACE","HOUSE"];$("ranking").innerHTML=names.map((n,i)=>`<div class="rank-row"><span>#${i+1}　${n}</span><b>${fmt(i?250000-i*28000:S.maxwin)} COIN</b><small>${i?"ONLINE":"YOU"}</small></div>`).join("")}
function puchun(){if(!S.sound){ } else {if(audioCtx)audioCtx.suspend().catch(()=>{});tone(55,.16,"sawtooth",.05);setTimeout(()=>audioCtx&&audioCtx.resume().catch(()=>{}),300)}let e=$("blackout");e.style.display="flex";setTimeout(()=>e.style.display="none",2200)}
function openGame(g){let title={slot:"ULTIMATE SLOTS",dice:"HIGH DICE",blackjack:"BLACKJACK",holdem:"TEXAS HOLD'EM",roulette:"ROULETTE",highlow:"HIGH & LOW",chohan:"丁半",coin:"COIN FLIP",lottery:"LOTTERY",multiplier:"CRASH ×",daily:"DAILY VAULT",shop:"CHIP SHOP"}[g];$("modalContent").innerHTML=`<div class="game"><div class="jackpot">GAMBLE BOX / ${title}</div><h2>${title}</h2><div id="gameBody"></div></div>`;$("modal").classList.remove("hidden");sfx("click");games[g]()}
function closeGame(){clearInterval(timer);$("modal").classList.add("hidden");sfx("click")}
function betbox(n=100){return `<div class="betrow"><input id="bet" type="number" min="1" value="${n}"><button class="primary" onclick="sfx('click')">BET SET</button></div>`}
function scrollToGames(){$("games").scrollIntoView()}
function toggleSound(){S.sound=!S.sound;$("sound").textContent=S.sound?"🔊":"🔇";if(S.sound)sfx("win");save()}

const games={
slot(){gameBody.innerHTML=betbox()+`<div class="reels"><div class="reel" id="r1">7️⃣</div><div class="reel" id="r2">7️⃣</div><div class="reel" id="r3">7️⃣</div></div><button onclick="slotSpin()">SPIN</button><div id="res" class="result"></div>`},
dice(){gameBody.innerHTML=betbox()+`<div class="choices"><button onclick="dice('high')">HIGH ×1.8</button><button onclick="dice('low')">LOW ×1.8</button><button onclick="dice('exact')">EXACT ×5</button></div><div id="res" class="result">🎲</div>`},
blackjack(){gameBody.innerHTML=betbox(100)+`<div class="felt"><div class="street">BLACKJACK TABLE</div><div>DEALER</div><div id="dealer" class="holdem-row"></div><div class="pot">BET <span id="bjbet">0</span></div><div>PLAYER</div><div id="player" class="holdem-row"></div><div class="actions"><button id="bjdeal" onclick="bjDeal()">DEAL</button><button id="bjhit" onclick="bjHit()" disabled>HIT</button><button id="bjstand" onclick="bjStand()" disabled>STAND</button><button id="bjdouble" onclick="bjDouble()" disabled>DOUBLE</button><button id="bjsplit" onclick="BJ.split?bjSplitAction():bjSplit()" disabled>SPLIT</button></div><div id="bjres" class="result"></div></div>`},
holdem(){holdemInit()},
roulette(){gameBody.innerHTML=betbox()+`<div class="choices"><button onclick="roulette('red')">🔴 RED ×2</button><button onclick="roulette('black')">⚫ BLACK ×2</button><button onclick="roulette('green')">🟢 ZERO ×14</button></div><div id="res" class="result">0 — 36</div>`},
highlow(){gameBody.innerHTML=betbox()+`<div id="card" class="result">7</div><div class="choices"><button onclick="hl('high')">HIGH</button><button onclick="hl('low')">LOW</button></div>`},
chohan(){gameBody.innerHTML=betbox()+`<div class="choices"><button onclick="ch('丁')">丁</button><button onclick="ch('半')">半</button></div><div id="res" class="result">🎯</div>`},
coin(){gameBody.innerHTML=betbox()+`<div class="choices"><button onclick="coin('表')">表</button><button onclick="coin('裏')">裏</button></div><div id="res" class="result">🪙</div>`},
lottery(){gameBody.innerHTML=`<p>ONE DRAW / 100 COIN</p><p>JACKPOT 100,000　•　1 / 500</p><p>GOLD 10,000　•　1 / 50</p><p>SILVER 500　•　約1 / 8</p><button onclick="lottery()">DRAW LOTTERY</button><div id="res" class="result">?</div>`},
multiplier(){gameBody.innerHTML=betbox()+`<div id="mult" class="result">1.00×</div><div class="meter"><i id="meter"></i></div><button onclick="crashStart()">START</button><div id="res"></div>`},
daily(){let ok=Date.now()-S.lastDaily>86400000;gameBody.innerHTML=`<p>${ok?"VAULT READY":"VAULT LOCKED"}</p><button ${ok?"":"disabled"} onclick="daily()">CLAIM 1,000</button><div id="res" class="result"></div>`},
shop(){gameBody.innerHTML=`<div class="shop-item">🎩 LUCKY HAT <button onclick="buy('Lucky Hat',3000)">3,000</button></div><div class="shop-item">💎 GOLD CHIP <button onclick="buy('Gold Chip',10000)">10,000</button></div><div class="shop-item">👑 JACKPOT CROWN <button onclick="buy('Crown',50000)">50,000</button></div><div id="res" class="result"></div>`}
};

function slotSpin(){let b=wager($("bet").value);if(!b)return;sfx("spin");let a=["🍒","🍋","🔔","💎","7️⃣"];for(let i=1;i<4;i++){setTimeout(()=>{$("r"+i).textContent=a[Math.floor(Math.random()*a.length)];sfx("spin")},i*260)}setTimeout(()=>{let r=[1,2,3].map(i=>$("r"+i).textContent),m=r[0]===r[1]&&r[1]===r[2]?(r[0]==="7️⃣"?50:15):r[0]===r[1]?3:0;$("res").textContent=m?`BIG WIN ×${m}`:"LOSE";settle(b,b*m,"ULTIMATE SLOTS");m?sfx(m>=15?"jackpot":"win"):sfx("lose");if(m>=15)puchun()},900)}
function dice(c){let b=wager($("bet").value);if(!b)return;sfx("dice");let d=1+Math.floor(Math.random()*6),ok=c==="exact"?d===6:c==="high"?d>=4:d<=3;$("res").textContent=`🎲 ${d} / ${ok?"WIN":"LOSE"}`;settle(b,ok?Math.floor(b*(c==="exact"?5:1.8)):0,"HIGH DICE");sfx(ok?"win":"lose")}
function deck(){let suits=["♠","♥","♦","♣"],ranks=["2","3","4","5","6","7","8","9","10","J","Q","K","A"],d=[];for(let s of suits)for(let r of ranks)d.push({s,r});return d.sort(()=>Math.random()-.5)}
function val(cards){let total=0,aces=0;cards.forEach(c=>{if(["J","Q","K"].includes(c.r))total+=10;else if(c.r==="A"){total+=11;aces++}else total+=+c.r});while(total>21&&aces--)total-=10;return total}
let BJ={};
function cardEl(c, hidden=false){
  if(hidden) return '<div class="card back">?</div>';
  return `<div class="card ${c.s==="♥"||c.s==="♦"?"red":""} dealt">${c.r}${c.s}</div>`;
}
function bjRender(){
  $("player").innerHTML=BJ.p.map(c=>cardEl(c)).join("");
  $("dealer").innerHTML=BJ.d.map((c,i)=>cardEl(c, i===1&&!BJ.reveal)).join("");
  $("bjbet").textContent=fmt(BJ.bet);
}
function bjSetActions(active){
  ["bjhit","bjstand","bjdouble","bjsplit"].forEach(id=>$(id).disabled=!active);
}
function bjDeal(){
  let b=wager($("bet").value); if(!b)return;
  BJ={deck:deck(),p:[ ],d:[],bet:b,reveal:false,over:false,split:false};
  BJ.p=[BJ.deck.pop(),BJ.deck.pop()];
  BJ.d=[BJ.deck.pop(),BJ.deck.pop()];
  bjRender(); sfx("deal");
  $("bjdeal").disabled=true;
  let canSplit=BJ.p[0].r===BJ.p[1].r && S.coins>=b;
  $("bjsplit").disabled=!canSplit;
  $("bjdouble").disabled=S.coins<b;
  if(val(BJ.p)===21){
    BJ.reveal=true; BJ.over=true; bjRender();
    $("bjres").textContent="BLACKJACK!";
    settle(BJ.bet,Math.floor(BJ.bet*2.5),"BLACKJACK");
    sfx("jackpot"); puchun(); bjSetActions(false); return;
  }
  bjSetActions(true);
}
function bjHit(){
  if(BJ.over)return;
  BJ.p.push(BJ.deck.pop()); sfx("card"); bjRender();
  let v=val(BJ.p);
  if(v>21){
    BJ.reveal=true; BJ.over=true; bjRender();
    $("bjres").textContent="BUST";
    settle(BJ.bet,0,"BLACKJACK"); sfx("lose"); bjSetActions(false);
  } else if(v===21){
    bjStand();
  }
}
function bjStand(){
  if(BJ.over)return;
  BJ.reveal=true;
  while(val(BJ.d)<17){ BJ.d.push(BJ.deck.pop()); sfx("card"); }
  BJ.over=true; bjRender(); bjResolve();
}
function bjDouble(){
  if(BJ.over||S.coins<BJ.bet)return;
  S.coins-=BJ.bet; S.wagered+=BJ.bet; BJ.bet*=2;
  BJ.p.push(BJ.deck.pop()); sfx("card");
  if(val(BJ.p)>21){
    BJ.reveal=true; BJ.over=true; bjRender();
    $("bjres").textContent="DOUBLE BUST";
    settle(BJ.bet,0,"BLACKJACK"); sfx("lose"); bjSetActions(false); return;
  }
  BJ.reveal=true;
  while(val(BJ.d)<17){BJ.d.push(BJ.deck.pop());sfx("card")}
  BJ.over=true; bjRender(); bjResolve();
}
function bjSplit(){
  if(BJ.over||BJ.split||BJ.p.length!==2||BJ.p[0].r!==BJ.p[1].r||S.coins<BJ.bet)return;
  // Split is handled as two hands with sequential player decisions.
  S.coins-=BJ.bet; S.wagered+=BJ.bet;
  BJ.split=true;
  BJ.hands=[
    [BJ.p[0],BJ.deck.pop()],
    [BJ.p[1],BJ.deck.pop()]
  ];
  BJ.handIndex=0; BJ.p=BJ.hands[0]; BJ.originalBet=BJ.bet;
  $("bjres").textContent="SPLIT — HAND 1";
  bjRender(); sfx("card");
  $("bjsplit").disabled=true;
}
function bjResolve(){
  let pv=val(BJ.p), dv=val(BJ.d), payout=0, msg;
  if(dv>21 || pv>dv){msg="YOU WIN";payout=BJ.bet*2}
  else if(pv===dv){msg="PUSH";payout=BJ.bet}
  else msg="DEALER WINS";
  $("bjres").textContent=`${msg}　YOU ${pv} / DEALER ${dv}`;
  settle(BJ.bet,payout,"BLACKJACK");
  sfx(payout>BJ.bet?"win":payout===BJ.bet?"click":"lose");
  bjSetActions(false);
  $("bjdeal").disabled=false;
  if(pv===21 && BJ.p.length===2){sfx("jackpot");puchun()}
}

function bjSplitAction(){
  if(!BJ.split)return;
  if(BJ.handIndex===0){
    BJ.hands[0]=BJ.p.slice();
    BJ.handIndex=1; BJ.p=BJ.hands[1];
    $("bjres").textContent="SPLIT — HAND 2"; bjRender(); bjSetActions(true);
  } else {
    // resolve both split hands against dealer
    BJ.hands[1]=BJ.p.slice();
    BJ.reveal=true;
    while(val(BJ.d)<17) BJ.d.push(BJ.deck.pop());
    let dv=val(BJ.d), totalPayout=0, labels=[];
    BJ.hands.forEach((hand,i)=>{
      let pv=val(hand), p=0, label;
      if(pv>21){label=`HAND ${i+1}: BUST`}
      else if(dv>21||pv>dv){p=hand===BJ.hands[0]?BJ.originalBet*2:BJ.originalBet*2;label=`HAND ${i+1}: WIN`;totalPayout+=p}
      else if(pv===dv){p=BJ.originalBet;label=`HAND ${i+1}: PUSH`;totalPayout+=p}
      else label=`HAND ${i+1}: LOSE`;
      labels.push(label);
    });
    BJ.over=true; BJ.p=BJ.hands[1]; bjRender();
    $("bjres").textContent=labels.join("　");
    settle(BJ.originalBet*2,totalPayout,"BLACKJACK SPLIT");
    sfx(totalPayout> BJ.originalBet*2?"win":totalPayout===BJ.originalBet*2?"click":"lose");
    bjSetActions(false); $("bjdeal").disabled=false;
  }
}
let H={};
function holdemInit(){H={deck:deck(),hero:[],villain:[],board:[],pot:0,currentBet:0,heroPaid:0,villainPaid:0,street:0,fold:false,over:false,ante:100};gameBody.innerHTML=`<div class="felt"><div class="street" id="hstreet">PRE-FLOP</div><div>VILLAIN</div><div id="villain" class="holdem-row"></div><div class="pot">POT <span id="hpot">0</span></div><div>BOARD</div><div id="board" class="holdem-row"></div><div>YOU</div><div id="hero" class="holdem-row"></div><div id="hstatus" class="result"></div><div class="actions"><button onclick="hCheck()">CHECK / CALL</button><button onclick="hBet(100)">BET 100</button><button onclick="hBet(500)">BET 500</button><button onclick="hBet(1000)">BET 1000</button><button onclick="hRaise()">RAISE</button><button onclick="hFold()">FOLD</button></div><div class="raisebox"><input id="hraise" type="number" min="1" value="100"><button onclick="hRaiseCustom()">RAISE CUSTOM</button></div></div><p class="hint">※ CPU 1人対戦。BET/RAISE額は自分で決定できます。</p>`;hStart()}
function hStart(){let b=100;if(S.coins<b*2){$("hstatus").textContent="100 COIN以上必要";return}S.coins-=b;S.wagered+=b;H.hero=[H.deck.pop(),H.deck.pop()];H.villain=[H.deck.pop(),H.deck.pop()];H.pot=b*2;H.heroPaid=b;H.villainPaid=b;hRender();sfx("deal")}
function hRender(){let names=["PRE-FLOP","FLOP","TURN","RIVER","SHOWDOWN"];$("hstreet").textContent=names[H.street];$("hpot").textContent=fmt(H.pot);$("hero").innerHTML=H.hero.map(cardEl).join("");$("villain").innerHTML=H.over?H.villain.map(cardEl).join(""):'<div class="card back">?</div><div class="card back">?</div>';$("board").innerHTML=H.board.map(cardEl).join("");}
function hNeedCall(){return Math.max(0,H.villainPaid-H.heroPaid)}
function hCheck(){if(H.over)return;let call=hNeedCall();if(call>0){if(S.coins<call){$("hstatus").textContent="COIN不足";return}S.coins-=call;S.wagered+=call;H.heroPaid+=call;H.pot+=call;sfx("chip")}else sfx("click");hCpu()}
function hBet(amount){if(H.over)return;let call=hNeedCall(),need=call+amount;if(S.coins<need){$("hstatus").textContent="COIN不足";return}S.coins-=need;S.wagered+=need;H.heroPaid+=need;H.currentBet=amount;H.pot+=need;sfx("chip");hCpu(true)}
function hRaiseCustom(){let a=Number($("hraise").value);if(a>0)hBet(a)}
function hRaise(){hBet(Math.max(100,H.currentBet*2||200))}
function hFold(){if(H.over)return;H.over=true;S.coins+=H.pot;S.history.unshift({g:"TEXAS HOLD'EM",net:H.pot-H.heroPaid,t:new Date().toLocaleTimeString()});S.history=S.history.slice(0,20);save();$("hstatus").textContent="FOLD — POT RETURNED";sfx("lose");hRender()}
function hCpu(aggressive=false){let call=hNeedCall();let strength=Math.random();if(strength<.18&&call>0){H.over=true;S.coins+=H.pot;S.history.unshift({g:"TEXAS HOLD'EM",net:-H.heroPaid,t:new Date().toLocaleTimeString()});S.history=S.history.slice(0,20);save();$("hstatus").textContent="CPU FOLDS — YOU WIN";sfx("win");hRender();return}let extra=aggressive?Math.floor(Math.random()*300):Math.floor(Math.random()*150);if(extra>0&&S.coins>=extra){H.villainPaid+=extra;H.pot+=extra}if(H.street<3){if(call>0&&H.villainPaid>H.heroPaid){let diff=H.villainPaid-H.heroPaid;if(S.coins>=diff){S.coins-=diff;S.wagered+=diff;H.heroPaid+=diff;H.pot+=diff}}dealStreet();save()}else showdown()}
function dealStreet(){H.street++;if(H.street===1)H.board.push(H.deck.pop(),H.deck.pop(),H.deck.pop());else H.board.push(H.deck.pop());hRender();sfx("card");$("hstatus").textContent="YOUR ACTION"}
function best5(cards){let combos=[];function rec(start,arr){if(arr.length===5){combos.push(arr.slice());return}for(let i=start;i<cards.length;i++){arr.push(cards[i]);rec(i+1,arr);arr.pop()}}rec(0,[]);let best=null;for(let c of combos){let r=handRank(c);if(!best||r.score>best.score)best={score:r.score,name:r.name,cards:c}}return best}
function handRank(cs){let vals=cs.map(c=>c.r==="A"?14:["K","Q","J"].includes(c.r)?({K:13,Q:12,J:11}[c.r]):+c.r).sort((a,b)=>b-a);let cnt={};vals.forEach(v=>cnt[v]=(cnt[v]||0)+1);let flush=cs.every(c=>c.s===cs[0].s);let uniq=[...new Set(vals)];if(uniq.includes(14))uniq.push(1);let straight=0;for(let i=0;i<=uniq.length-5;i++)if(uniq[i]-uniq[i+4]===4){straight=uniq[i];break}if(flush&&straight)return{score:800+straight,name:"STRAIGHT FLUSH"};let groups=Object.entries(cnt).sort((a,b)=>b[1]-a[1]||b[0]-a[0]);if(groups[0][1]===4)return{score:700+ +groups[0][0],name:"FOUR OF A KIND"};if(groups[0][1]===3&&groups[1][1]===2)return{score:600+ +groups[0][0],name:"FULL HOUSE"};if(flush)return{score:500+vals[0],name:"FLUSH"};if(straight)return{score:400+straight,name:"STRAIGHT"};if(groups[0][1]===3)return{score:300+ +groups[0][0],name:"THREE OF A KIND"};if(groups[0][1]===2&&groups[1][1]===2)return{score:200+Math.max(+groups[0][0],+groups[1][0]),name:"TWO PAIR"};if(groups[0][1]===2)return{score:100+ +groups[0][0],name:"ONE PAIR"};return{score:vals[0],name:"HIGH CARD"}}
function showdown(){H.over=true;H.street=4;let a=best5([...H.hero,...H.board]),b=best5([...H.villain,...H.board]);let payout=0,msg;if(a.score>b.score){payout=H.pot*2;msg=`YOU WIN — ${a.name}`}else if(a.score===b.score){payout=H.pot;msg=`PUSH — ${a.name}`}else msg=`CPU WINS — ${b.name}`;settle(H.heroPaid,payout,"TEXAS HOLD'EM");$("hstatus").textContent=msg;sfx(payout>H.heroPaid?"win":payout===H.heroPaid?"click":"lose");if(a.name==="STRAIGHT FLUSH"&&a.score>=814)puchun();hRender()}

function roulette(c){let b=wager($("bet").value);if(!b)return;sfx("roulette");let n=Math.floor(Math.random()*37),red=[1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(n),co=n===0?"green":red?"red":"black",ok=co===c;$("res").textContent=`${n}　${co.toUpperCase()}　${ok?"WIN":"LOSE"}`;settle(b,ok?b*(c==="green"?14:2):0,"ROULETTE");sfx(ok?"win":"lose");if(c==="green"&&ok)puchun()}
function hl(c){let b=wager($("bet").value),n=1+Math.floor(Math.random()*13),ok=c==="high"?n>=8:n<=6;$("card").textContent=n;sfx("card");settle(b,ok?Math.floor(b*1.8):0,"HIGH & LOW");sfx(ok?"win":"lose")}
function ch(c){let b=wager($("bet").value),s=2+Math.floor(Math.random()*11),r=s%2?"半":"丁";$("res").textContent=`${s} → ${r}`;sfx("dice");settle(b,r===c?b*2:0,"丁半");sfx(r===c?"win":"lose")}
function coin(c){let b=wager($("bet").value),r=Math.random()<.5?"表":"裏";$("res").textContent=r;sfx("flip");settle(b,r===c?b*2:0,"COIN FLIP");sfx(r===c?"win":"lose")}
function lottery(){let b=wager(100);if(!b)return;let r=Math.random(),p=r<.002?100000:r<.022?10000:r<.147?500:0;$("res").textContent=p?`🎉 ${fmt(p)} COIN`:"MISS";settle(b,p,"LOTTERY");sfx(p>=10000?"jackpot":p?"win":"lose");if(p>=10000)puchun()}
function crashStart(){let b=wager($("bet").value);if(!b)return;multi=1;sfx("spin");clearInterval(timer);$("res").innerHTML=`<button onclick="cash()">CASH OUT</button>`;timer=setInterval(()=>{multi*=1+Math.random()*.055;$("mult").textContent=multi.toFixed(2)+"×";$("meter").style.width=Math.min(100,multi/8*100)+"%";if(Math.random()<.018)crash()},260)}
function crash(){clearInterval(timer);$("res").textContent="💥 CRASH";sfx("crash");settle(lastBet,0,"CRASH ×")}
function cash(){clearInterval(timer);$("res").textContent=`CASH OUT ${multi.toFixed(2)}×`;settle(lastBet,Math.floor(lastBet*multi),"CRASH ×");sfx(multi>=5?"jackpot":"win");if(multi>=10)puchun()}
function daily(){if(Date.now()-S.lastDaily<=86400000)return;S.coins+=1000;S.lastDaily=Date.now();save();$("res").textContent="+1,000 COIN";sfx("win")}
function buy(n,p){if(S.coins<p){$("res").textContent="INSUFFICIENT COINS";sfx("lose");return}S.coins-=p;S.items.push(n);save();$("res").textContent="PURCHASED: "+n;sfx("chip")}
document.querySelectorAll("#tabs button").forEach(b=>b.onclick=()=>{document.querySelectorAll("#tabs button").forEach(x=>x.classList.remove("active"));b.classList.add("active");let f=b.dataset.filter;document.querySelectorAll(".gamecard").forEach(c=>c.style.display=f==="all"||c.dataset.cat===f?"":"none");sfx("click")});
document.addEventListener("pointerdown",()=>{let a=audio();if(a&&a.state==="suspended")a.resume()},{once:true});
render();